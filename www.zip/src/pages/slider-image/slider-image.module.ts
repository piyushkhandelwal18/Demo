import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SliderImagePage } from './slider-image';

@NgModule({
  declarations: [
    SliderImagePage,
  ],
  imports: [
    IonicPageModule.forChild(SliderImagePage),
  ],
})
export class SliderImagePageModule {}
