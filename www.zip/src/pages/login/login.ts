import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LoadingProvider } from './../../providers/loading/loading';
/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  
  mobileNumber : string
  isError : boolean

  constructor(public navCtrl: NavController, public navParams: NavParams, private loading: LoadingProvider) {
    
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
    //this.presentLoading();
  }

  showVerifyOTPPage() {
    console.log(this.mobileNumber);

    if(this.mobileNumber != null && this.mobileNumber.length == 10)
    {
      this.navCtrl.push('VerifyOtpPage', {
        mobileNumber: this.mobileNumber
      });
    }
    else
    {
        this.isError = true;
    }
    
  }

  showHomePage() {
    this.navCtrl.push('DashboardPage');
  }

  presentLoading() {
    this.loading.presentLoading();
  }
}
