import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LiveOrderPage } from './live-order';

@NgModule({
  declarations: [
    LiveOrderPage,
  ],
  imports: [
    IonicPageModule.forChild(LiveOrderPage),
  ],
})
export class LiveOrderPageModule {}
