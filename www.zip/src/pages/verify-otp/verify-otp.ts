import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Input, ViewChild} from '@angular/core';
/**
 * Generated class for the VerifyOtpPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-verify-otp',
  templateUrl: 'verify-otp.html',
})
export class VerifyOtpPage {

  @ViewChild('input1') otp1 ;
  @ViewChild('input2') otp2 ;
  @ViewChild('input3') otp3 ;
  @ViewChild('input4') otp4 ;

  mobileNumber : string

  val1 : string
  val2 : string
  val3 : string
  val4 : string
  orignalOTP : string

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.mobileNumber = navParams.get("mobileNumber");
    
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad VerifyOtpPage');
    //this.otp1.setFocus();
    setTimeout(() => {
      this.otp1.setFocus();
    },150)
  }

  

  SetFocus(focusField: string ){
    console.log(focusField);
    if(focusField == '1')
    {
      this.otp2.setFocus();
    }
    else if(focusField == '2')
    {
      this.otp3.setFocus();
    }
    else if(focusField == '3')
    {
      this.otp4.setFocus();
    }
    else if(focusField == '4')
    {
       this.VerifyOtp();
    }
      
      
  }

  VerifyOtp(){
    this.orignalOTP = '1234';
    var enteredOTP = this.val1 + this.val2 +this.val3+ this.val4;
    if(enteredOTP == this.orignalOTP)
    {
      console.log('OTP Verified');
      this.navCtrl.push('DashboardPage');
    }
    else
    {

    }
  }
}
