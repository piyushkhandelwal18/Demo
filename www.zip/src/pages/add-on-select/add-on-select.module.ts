import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddOnSelectPage } from './add-on-select';

@NgModule({
  declarations: [
    AddOnSelectPage,
  ],
  imports: [
    IonicPageModule.forChild(AddOnSelectPage),
  ],
})
export class AddOnSelectPageModule {}
