import { Injectable } from '@angular/core';
import { HttpModule, Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable'
import { Category, Blog, Store, Order, Product } from '../../models/model';
/*
  Generated class for the ApiProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/

const BASE_URL = 'http://api.ciferon.in/';

@Injectable()
export class ApiProvider {

  headers: Headers;
  options: RequestOptions;

  constructor(public http: Http) {
    this.headers = new Headers({ 'Authorization': 'Bearer 12345', 'CompanyId': '17', 'Content-Type': 'application/json', 'Accept': 'q=0.8;application/json;q=0.9' });
    this.options = new RequestOptions({ headers: this.headers });
  }

  //ORIGINAL IMPLEMENTATION
  // getProducts() : Observable<any>{
  //   return this.http.get('https://www.reddit.com/r/gifs/new/.json?limit=10').map(res => res.json())
  // }

  getProducts(): Observable<Category[]> {
    return this.http.get(BASE_URL + 'AppApi/CategoryAppApi/GetCategoryList_App', this.options).map((res) => {
      return <Category[]>res.json().CategoryAppListWrapper;
    });
  }

  getLocations(): Observable<Location[]> {
    return this.http.get(BASE_URL + 'AppApi/LocationAppApi/GetLocationList_App?storeid=1', this.options).map((res) => {
      return <Location[]>res.json().LocationAppListWrapper;
    });
  }

  getBlogs(): Observable<Blog[]> {
    return this.http.get(BASE_URL + 'AppApi/BlogAppApi/GetBlogList_App', this.options).map((res) => {
      return <Blog[]>res.json().BlogAppListWrapper;
    });
  }

  getStores(): Observable<Store[]> {
    return this.http.get(BASE_URL + 'AppApi/StoreAppApi/GetStoreList_App', this.options).map((res) => {
      return <Store[]>res.json().StoreAppListWrapper;
    });
  }

  getOrders(): Observable<Order[]> {
    return this.http.get(BASE_URL + 'AppApi/OrderAppApi/GetOrderList_App', this.options).map((res) => {
      return <Order[]>res.json().OrderAppListWrapper;
    });
  }

  getTodaySpecialProducts(): Observable<Product[]> {
    return this.http.get(BASE_URL + 'AppApi/TodaySpecialAppApi/GetTodaySpecialList_App', this.options).map((res) => {
      return <Product[]>res.json().TodaySpecialAppListWrapper;
    });
  }

}
