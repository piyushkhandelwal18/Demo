import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { HttpModule, Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { ApiProvider } from '../../providers/api/api';
import { ListPage } from '../list/list';
import { BlogPage } from '../blog/blog';
import { LoginPage } from '../login/login';
import { SuperTabsModule, SuperTabs } from 'ionic2-super-tabs';
import { ProductlistPage } from '../productlist/productlist';
import { Category } from '../../models/model';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  posts: any;

  tabRoot1: any = ProductlistPage;
  categoryList: Category[];
  selectedCategory: number = 0;
  index: number = 0;

  @ViewChild(SuperTabs) superTabs: SuperTabs;

  constructor(public navCtrl: NavController, public navParams: NavParams, private api: ApiProvider) {

    this.selectedCategory = navParams.get('id');
  }

  ionViewDidLoad() {
    this.api.getProducts().subscribe((customList: Category[]) => {
      

      for (var n = 0; n < customList.length; n++) {
        if (customList[n].CategoryId == this.selectedCategory) {
          this.index = n;
          break;
        }
      }
      this.categoryList = customList;
    });
  }

  showCart(){
    this.navCtrl.push('CartPage');
  }

}
