import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the SelectStoresPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-select-stores',
  templateUrl: 'select-stores.html',
})
export class SelectStoresPage {

  storeList: any

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  this.storeList = navParams.get('storeList');
  console.log(this.storeList);  
  }

  ionViewDidLoad() {
    console.log( this.distance(21.1213562, 78.9772441,  79.0797531,21.1377116,));
  }

  distance(lat1, lon1, lat2, lon2) {
    var p = 0.017453292519943295;    // Math.PI / 180
    var c = Math.cos;
    var a = 0.5 - c((lat2 - lat1) * p)/2 + 
            c(lat1 * p) * c(lat2 * p) * 
            (1 - c((lon2 - lon1) * p))/2;
  
    return 12742 * Math.asin(Math.sqrt(a)); // 2 * R; R = 6371 km
  }
}
