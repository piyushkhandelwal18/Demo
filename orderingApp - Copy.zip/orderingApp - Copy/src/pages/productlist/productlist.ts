import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController } from 'ionic-angular';
import { Product } from '../../models/model';

/**
 * Generated class for the ProductlistPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-productlist',
  templateUrl: 'productlist.html',
})
export class ProductlistPage {

  productList: Product[];

  constructor(public navCtrl: NavController, public navParams: NavParams, public modalCtrl: ModalController) {
    this.productList = navParams.get('id');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ProductlistPage');
  }

  addItemToCart(id: number) {
    let selectedProduct: Product;
    let hasAddon: boolean;
    for (var n = 0; n < this.productList.length; n++) {
      if (this.productList[n].ProductId == id) {
        selectedProduct = this.productList[n];
        break;
      }
    }

    if (selectedProduct.AddOnList != undefined && selectedProduct.AddOnList.length > 0) {
      hasAddon = true;
    }
    else if (selectedProduct.ComboGroupList != undefined && selectedProduct.ComboGroupList.length > 0) {
      hasAddon = true;
    }
    else {
      hasAddon = false;
    }

    if (hasAddon) {
      this.presentModal(selectedProduct);
    }
    else {
      this.addToOrderItem(this.productList[n]);
    }
  }

  private addToOrderItem(product: Product) {
    console.log('add1');
  }

  presentModal(selectedProduct: Product) {
    console.log('add');
    let modal = this.modalCtrl.create('AddonPage', {product: selectedProduct});
    modal.present();
  }

}
