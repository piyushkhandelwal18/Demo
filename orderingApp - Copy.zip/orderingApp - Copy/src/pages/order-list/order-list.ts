import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api';
import { Order } from '../../models/model';

@IonicPage()
@Component({
  selector: 'page-order-list',
  templateUrl: 'order-list.html',
})
export class OrderListPage {

  orderList: any;

  constructor(public navCtrl: NavController, public api: ApiProvider) {
    this.api.getOrders().subscribe((customList: Order[]) => {
      this.orderList = customList;
    });
  }

  ionViewDidLoad() {
  }

  showOrderDetail(id : number){
    this.navCtrl.push('OrderDetailPage');
  }

}
