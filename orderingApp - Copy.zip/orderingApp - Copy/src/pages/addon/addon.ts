import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Product } from '../../models/model';

/**
 * Generated class for the AddonPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-addon',
  templateUrl: 'addon.html',
})
export class AddonPage {

  product: Product;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.product = navParams.get('product');
    console.log(this.product);
  }

  ionViewDidLoad() {
  }

  closeModal() {
    this.clearSelection();
    this.navCtrl.pop();
  }

  onAddOnSelected(id: number) {

    for (var n = 0; n < this.product.AddOnList.length; n++) {
      if (this.product.AddOnList[n].ProductId == id) {
        this.product.AddOnList[n].IsSelected = !this.product.AddOnList[n].IsSelected;
        break;
      }
    }
  }

  get hasAddon(): boolean {
    if (this.product.AddOnList != undefined && this.product.AddOnList.length > 0)
      return true;
    else
      return false;
  }

  get total() {

    let total = this.product.MinSalePrice;
    if (this.product.AddOnList != undefined) {
      this.product.AddOnList.forEach(element => {
        if (element.IsSelected) {
          total = total + element.MinSalePrice;
        }
      });
    }
    // if (this.product.ComboGroupList != undefined) {
    //   this.product.ComboGroupList.forEach(element => {
    //     if (element.IsSelected) {
    //       total = total + element.MinSalePrice;
    //     }
    //   });
    // }
    return total;
  }

  private clearSelection() {
    if (this.product.AddOnList != undefined) {
      this.product.AddOnList.forEach(element => {
        element.IsSelected = false;

      });
    }
  }
}
