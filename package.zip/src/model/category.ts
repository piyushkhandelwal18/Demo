export class Category {
    CategoryId: number = 0;
    CategoryName: string = '';
    ImgUrl: string;
    ProductList: Product[];
}

export interface ICategory {
    CategoryId: number;
    CategoryName: string;
    ImgUrl: string;
    ProductList: Product[];
}

export class Product {
    ProductId: number = 0;
    ProductName: string = '';
    MinSalePrice: number = 0;
    IsAddon: boolean;
    IsSelected: boolean = false;
    AddOnList: Product[];

    get total(){
        return 100;
    }
}

export class User {

}

export class Order{
    OrderItemList: OrderItem[];
}

export class OrderItem {
    OrderItem: number;
    ProductId: number;
    Product: Product;
    Quantity: number;
    UniqueId: number;
    CustomizeText: string;
    AddOnList: Product[];


    constructor() {

    }

    
}

export interface Blog {
    BlogId: number;
    Heading?: any;
    Description: string;
    ImageUrl: string;
}

export class Location {
    LocationId: number;
    AreaName: string;
    PinCode: string;
}

export class Store {
    StoreID: number;
    StoreName: string;
}

export class CategoryAppListWrapper {
    CategoryList: Category[];
}