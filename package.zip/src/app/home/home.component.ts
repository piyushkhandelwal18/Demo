import { Component, OnInit } from '@angular/core';
import { Category, ICategory, Product, OrderItem, Store } from '../../model/category';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  storeList: any;
  locationList: any;
  selectedStore: Store;

  constructor(private productService: ProductService) { 
    this.selectedStore = new Store();
    this.selectedStore.StoreName = "Select Store";
  }

  ngOnInit() {
    this.productService.getStores().subscribe((customList: Store[]) => {
      this.storeList = customList;
      if(this.storeList.length == 1)
      {
        this.selectedStore = this.storeList[0];
      }
      console.log(this.storeList);
    });
       
    this.productService.getLocations().subscribe((customList: Location[]) => {
      this.locationList = customList;
      console.log(this.locationList);
    });
  }

  selectStore(selectedStore: Store){
    this.selectedStore = selectedStore;
  }
}
