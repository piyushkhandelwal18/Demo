import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { ROUTING } from './app.routing';
import { HomeComponent } from './home/home.component';
import { BlogComponent } from './blog/blog.component';
import { StoresComponent } from './stores/stores.component';
import { TodayspecialComponent } from './todayspecial/todayspecial.component';
import { BulkorderComponent } from './bulkorder/bulkorder.component';
import { RecipeComponent } from './recipe/recipe.component'
import { HttpModule } from '@angular/http';
import { ApiService } from './api.service';
import { ConstantService } from './constant.service';
import { ProductService } from './product.service';
import { LoginModalComponent } from './login-modal/login-modal.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalStack } from '@ng-bootstrap/ng-bootstrap/modal/modal-stack';
import { NgbModalBackdrop } from '@ng-bootstrap/ng-bootstrap/modal/modal-backdrop';
import { NgbModalWindow } from '@ng-bootstrap/ng-bootstrap/modal/modal-window';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ConfirmService, ConfirmState } from './services/modalservice.service';

@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    HomeComponent,
    BlogComponent,
    StoresComponent,
    TodayspecialComponent,
    BulkorderComponent,
    RecipeComponent,
    LoginModalComponent,
    NgbModalBackdrop,
    NgbModalWindow
  ],
  entryComponents: [NgbModalBackdrop, NgbModalWindow],
  imports: [ 
    BrowserModule,
    ROUTING,
    HttpModule,
    FormsModule
  ],
  providers: [ApiService, ProductService, ConstantService, NgbModal, NgbModalStack, ConfirmService,ConfirmState],
  bootstrap: [AppComponent]
})
export class AppModule { }
