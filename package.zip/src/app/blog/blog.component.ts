import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { Blog } from '../../model/category';
import { ProductService } from '../product.service';
import { ConfirmService } from './../services/modalservice.service';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css']
})
export class BlogComponent implements OnInit {

  blogList: any;

  constructor(private service: ProductService, private modalService: NgbModal, private confirmService: ConfirmService) { }

  closeResult: string;

  ngOnInit() {
    this.service.getBlogs().subscribe((customList: Blog[]) => {
      this.blogList = customList;
      console.log('products' + customList);
    });
  }

  open(content) {
    // this.modalService.open(content).result.then((result) => {
    //   this.closeResult = `Closed with: ${result}`;
    // }, (reason) => {
    //   this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    // });

    this.confirmService.confirm({ title:'Confirm deletion', message: 'Do you really want to delete this foo?' }).then(
      () => {
        console.log('deleting...');
      },
      () => {
        console.log('not deleting...');
      });
  }

  private getDismissReason(reason: any): string {
    console.log(reason);
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

}
