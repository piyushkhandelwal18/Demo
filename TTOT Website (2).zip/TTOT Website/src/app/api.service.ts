import { Injectable } from '@angular/core';
import { Jsonp, URLSearchParams, Response, Http } from '@angular/http';
import { Category } from '../model/category';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { ConstantService } from './constant.service';
import { Headers, RequestOptions } from '@angular/http';
//import { HttpClient } from 'selenium-webdriver/http';

@Injectable()
export class ApiService {

  headers: Headers;
  options: RequestOptions;
  categoryList: Array<Category>

  constructor(private http: Http, private constant: ConstantService) {
    this.headers = new Headers({ 'Authorization': 'Bearer xdP6pNp6ac8cSN/EW1JSZylHFIeEOoXuca19ksAE2hHqO5mGK11LQ+rSYXJe6cdA7H8eKVc+E0KSxca56M6m/dGvswfOEjgS5sU1YRRH3lmBwDGQwN6BvvKzkxQqOOZRxCdgCDbS2ZWqV587/1KMi3m4IURbaT8LTYPH/2HldKFTaGcV888WzS6sX+MEVZqi', 'Content-Type': 'application/json', 'Accept': 'q=0.8;application/json;q=0.9' });
    this.options = new RequestOptions({ headers: this.headers });
  }


  getProducts() {
    this.getData().subscribe(data => {
      console.log(data);
    })
  }

  getData() {
    let res = this.http.get('http://api.ciferon.in/AppApi/CategoryAppApi/GetCategoryList_App', this.options).map(this.extractData);
    console.log("result:", res);
    console.log('fdfs' + this.categoryList);
    return res;
  }

  // getProducts() : Observable<any>{
  //       console.log('api called');
  //       return this.http.get('http://api.ciferon.in/AppApi/LocationAppApi/GetCategoryList_App', this.options).map(data => data['_body']);
  //   } 

  private extractData(res: Response) {
    let body = res.json().CategoryAppListWrapper;
    let Category = Array<Category>();
    this.categoryList = body;
    console.log(body);
    return body || {};
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }

}
