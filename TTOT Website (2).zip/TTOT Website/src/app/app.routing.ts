import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core/src/metadata/ng_module';

import { HomeComponent } from './home/home.component';
import { ProductComponent } from './product/product.component';
import { BlogComponent } from './blog/blog.component';
import { StoresComponent } from './stores/stores.component';
import { TodayspecialComponent } from './todayspecial/todayspecial.component';
import { BulkorderComponent } from './bulkorder/bulkorder.component';
import { RecipeComponent } from './recipe/recipe.component';
import { LoginModalComponent } from './login-modal/login-modal.component';
import { PastOrdersComponent } from './past-orders/past-orders.component';
 
export const AppRoutes: Routes = [
    { path: '', component: HomeComponent },
    { path: 'products', component: ProductComponent },
    { path: 'blog', component: BlogComponent },
    { path: 'stores', component: StoresComponent },
    { path: 'todayspecial', component: TodayspecialComponent },
    { path: 'bulkorder', component: BulkorderComponent },
    { path: 'recipe', component: RecipeComponent },
    { path: 'loginModal', component: LoginModalComponent },
    { path: 'pastOrders', component: PastOrdersComponent }
];
 
export const ROUTING: ModuleWithProviders = RouterModule.forRoot(AppRoutes);