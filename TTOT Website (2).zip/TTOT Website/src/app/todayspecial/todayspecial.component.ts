import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-todayspecial',
  templateUrl: './todayspecial.component.html',
  styleUrls: ['./todayspecial.component.css']
})
export class TodayspecialComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
