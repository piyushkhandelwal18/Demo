import { Component, OnInit } from '@angular/core';
import { Category, ICategory, Product, OrderItem } from '../../model/category';
import { ProductService } from '../product.service';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  categoryList: any;
  productList: any;
  addOnList: any;
  cartList: any;
  selectedCategoryId: number;
  private allProductList: any;
  currentProduct: Product;
  closeResult: string;

  constructor(private productService: ProductService, private modalService: NgbModal) {

  }

  ngOnInit() {
    console.log('fetch started products');
    this.productService.getProducts().subscribe((customList: Category[]) => {
      this.categoryList = customList;
      this.productList = customList[0].ProductList;
      this.selectedCategoryId = customList[0].CategoryId;
      this.allProductList = new Array<Product>();
      this.categoryList.forEach(element => {
        this.allProductList = this.allProductList.concat(element.ProductList);
      });

      console.log('products' + customList);
    });
  }

  showProducts(itemId: number) {
    this.selectedCategoryId = itemId;
    this.categoryList.forEach(element => {
      if (itemId == element.CategoryId) {
        this.productList = element.ProductList;
      }
    });
  }

  addItemToCart(itemId: number, content) {

    let customizeText = '';
    let selectedAddOns = new Array<OrderItem>();
    let uniqueId = Date.now();


    if (this.cartList == undefined) {
      this.cartList = new Array<OrderItem>();
    }

    this.allProductList.forEach(element => {
      if (itemId == element.ProductId) {
        this.currentProduct = element;
        console.log(element);
      }
    });
    let productTotal = this.currentProduct.MinSalePrice;
    
    if (this.currentProduct.AddOnList == undefined || this.currentProduct.AddOnList.length == 0) {
      let orderItem = this.createOrderItem(this.currentProduct);
      orderItem.CustomizeText = this.getAddonString(orderItem);
      this.cartList.push(orderItem);
    }
    else {
      this.addOnList = this.currentProduct.AddOnList;
      this.modalService.open(content).result.then((result) => {
        this.closeResult = `${result}`;
  
  
        if (this.closeResult == 'Add') {
          customizeText = '';
  
          let item = this.createOrderItem(this.currentProduct);
          item.AddOnList = new Array<Product>();
  
          this.productList.forEach(element => {
  
            if (element.IsSelected) {
              item.AddOnList.push(element);
            }
          });
  
          console.log('closed from add button');
          let orderItem = this.createOrderItem(this.currentProduct);
          orderItem.AddOnList = item.AddOnList;
          orderItem.CustomizeText = this.getAddonString(orderItem);
          this.cartList.push(orderItem);
  
        }
      }, (reason) => { });
    }
  }


  private createOrderItem(product: Product): OrderItem {
    let orderItem = new OrderItem();
    orderItem.Product = this.currentProduct;
    orderItem.Quantity = 1;
    orderItem.UniqueId = Date.now();
    return orderItem;
  }
  
  increaseQuantity(uniqueNumber: number) {
    console.log('Added' + uniqueNumber);

    this.cartList.forEach(element => {
      if (uniqueNumber == element.UniqueId) {
        console.log(this.cartList);
        element.Quantity = element.Quantity + 1;
      }
    });
    console.log(this.cartList);
  }


  decreaseQuantity(uniqueNumber: number) {
    this.cartList.forEach(element => {
      if (uniqueNumber == element.UniqueId) {
        if (element.Quantity == 1) {
          this.cartList = this.cartList.filter(item => item.uniqueNumber !== uniqueNumber);
        }
        else {
          element.Quantity = element.Quantity - 1;
        }

      }
    });
  }

  open(content) {
    this.modalService.open(content).result.then((result) => {
      this.closeResult = `${result}`;
      if (this.closeResult == 'Add') {
        console.log('closed from add button');
      }
    }, (reason) => { });
  }

  productTotal: number;

  onSelectionChanged(isSelected: boolean) {
    let productTotal = this.currentProduct.MinSalePrice;
    this.productList.forEach(element => {
      if (element.IsSelected) {
        productTotal = productTotal + element.MinSalePrice;
      }
    });
    this.productTotal = productTotal;
  }

  private getAddonString(orderItem: OrderItem) {
    let addOn = '';
    if (orderItem.AddOnList == undefined) {
      return addOn;
    }
    orderItem.AddOnList.forEach(element => {
      if (addOn == '') {
        addOn = element.ProductName;
      }
      else {
        addOn = addOn + ', ' + element.ProductName;
      }
    });
    console.log(addOn);
    return addOn;
  }

  get subTotal() {
    let total = 0;
    if (this.cartList != undefined) {
      this.cartList.forEach(element => {
        total = total + element.Product.MinSalePrice;
        if (element.AddOnList != undefined) {
          element.AddOnList.forEach(addOn => {
            total = total + addOn.MinSalePrice;
          });
        }
      });
    }
    return total;
  }

  get discount() {
    return 0;
  }

  get deliveryCharges() {
    return 0;
  }

  get orderTotal() {
    return this.subTotal - this.discount;
  }

  get IsCheckoutVisible(){
    if(this.cartList == undefined || this.cartList.length == 0){
      return false;
    }
    else{
      return true;
    }
  }

}
