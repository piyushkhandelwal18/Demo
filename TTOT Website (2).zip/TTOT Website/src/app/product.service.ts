import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { Category, ICategory, Blog, Store } from '../model/category';
import { Http, Response } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { Headers, RequestOptions } from '@angular/http';

@Injectable()
export class ProductService {

  headers: Headers;
  options: RequestOptions;
  BASE_URL: string; 

  constructor(private apiService: ApiService, private http: Http) {
    this.headers = new Headers({ 'Authorization': 'Bearer xdP6pNp6ac8cSN/EW1JSZylHFIeEOoXuca19ksAE2hHqO5mGK11LQ+rSYXJe6cdA7H8eKVc+E0KSxca56M6m/dGvswfOEjgS5sU1YRRH3lmBwDGQwN6BvvKzkxQqOOZRxCdgCDbS2ZWqV587/1KMi3m4IURbaT8LTYPH/2HldKFTaGcV888WzS6sX+MEVZqi', 'Content-Type': 'application/json', 'Accept': 'q=0.8;application/json;q=0.9' });
    this.options = new RequestOptions({ headers: this.headers });
    this.BASE_URL = 'http://api.ciferon.in/';
  }

  getProducts(): Observable<Category[]> {
    return this.http.get(this.BASE_URL + 'AppApi/CategoryAppApi/GetCategoryList_App', this.options).map((res: Response) => {
      return <Category[]>res.json().CategoryAppListWrapper;
    });
  }

  getLocations(): Observable<Location[]> {
    return this.http.get(this.BASE_URL + 'AppApi/LocationAppApi/GetLocationList_App?storeid=1', this.options).map((res: Response) => {
      return <Location[]>res.json().LocationAppListWrapper;
    });
  }

  getBlogs(): Observable<Blog[]> {
    return this.http.get(this.BASE_URL + 'AppApi/BlogAppApi/GetBlogList_App', this.options).map((res: Response) => {
      return <Blog[]>res.json().BlogAppListWrapper;
    });
  }

  getStores(): Observable<Store[]> {
    return this.http.get(this.BASE_URL + 'AppApi/StoreAppApi/GetStoreList_App', this.options).map((res: Response) => {
      return <Store[]>res.json().StoreAppListWrapper;
    });
  }
}
