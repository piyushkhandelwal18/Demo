import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, Searchbar, ModalController } from 'ionic-angular';
import { HttpModule, Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { ApiProvider } from '../../providers/api/api';
import { ListPage } from '../list/list';
import { BlogPage } from '../blog/blog';
import { LoginPage } from '../login/login';
import { SuperTabsModule, SuperTabs } from 'ionic2-super-tabs';
import { ProductlistPage } from '../productlist/productlist';
import { Category, Product, Order } from '../../models/model';
import { LocalStorageProvider } from '../../providers/storage/storage';
import { OrderProvider } from '../../providers/order/order';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {


  @ViewChild(SuperTabs) superTabs: SuperTabs;
  @ViewChild('searchbar') searchbar: Searchbar

  tabRoot1: any = ProductlistPage;
  categoryList: Category[];
  index: number = 0;
  searchResults: Product[];
  currentOrder: Order;
  public showSearchbar: boolean = false;

  constructor(public navCtrl: NavController, private api: ApiProvider, 
              public storage: LocalStorageProvider, private orderProvider: OrderProvider,
              private modal: ModalController) {
    this.showSearchbar = false;
    this.currentOrder = this.orderProvider.getCurrentOrder();
  }

  ionViewDidLoad() {
    this.categoryList = this.storage.categoryList;
  }

  ionViewDidEnter(){
    this.currentOrder = this.orderProvider.getCurrentOrder();
  }

  showCart() {
    this.navCtrl.push('DirectPaymentPage');
  }

  search(event: Event) {
    this.showSearchbar = true;
  }

  cancelSearch(event: Event) {
    this.showSearchbar = false;
  }

  showRunningOrders() {
    let modal = this.modal.create('RunningOrdersPage');
    modal.present();
  }

  public toggle(): void {
    this.showSearchbar = this.showSearchbar ? false : true;
    setTimeout(() => {
      this.searchbar.setFocus();
    }, 150);
  }
}
