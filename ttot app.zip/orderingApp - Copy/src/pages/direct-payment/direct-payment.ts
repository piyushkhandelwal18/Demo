import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController } from 'ionic-angular';
import { LocalStorageProvider } from '../../providers/storage/storage';
import { PaymentMode } from '../../models/model';

/**
 * Generated class for the DirectPaymentPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-direct-payment',
  templateUrl: 'direct-payment.html',
})
export class DirectPaymentPage {

  paymentModes: PaymentMode[];

  constructor(public navCtrl: NavController, public navParams: NavParams, private storage: LocalStorageProvider, public modalCtrl: ModalController) {
    this.paymentModes = storage.paymentModeList;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DirectPaymentPage');
  }

  splitPayment() {
    // let modal = this.modalCtrl.create('SplitPaymentPage');
    // modal.present();
    this.navCtrl.push('SplitPaymentPage');
  }

  showCharges() {
    // let modal = this.modalCtrl.create('AdditionalChargesPage');
    // modal.present();
    this.navCtrl.push('AdditionalChargesPage');
  }

}
