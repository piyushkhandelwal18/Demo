import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdditionalChargesPage } from './additional-charges';

@NgModule({
  declarations: [
    AdditionalChargesPage,
  ],
  imports: [
    IonicPageModule.forChild(AdditionalChargesPage),
  ],
})
export class AdditionalChargesPageModule {}
