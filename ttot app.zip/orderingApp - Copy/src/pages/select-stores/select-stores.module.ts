import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SelectStoresPage } from './select-stores';

@NgModule({
  declarations: [
    SelectStoresPage,
  ],
  imports: [
    IonicPageModule.forChild(SelectStoresPage),
  ],
})
export class SelectStoresPageModule {}
