import { Injectable } from '@angular/core';
import { Ledger, Order, Customer } from '../../models/model';

/*
  Generated class for the OrderProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class OrderProvider {

  orderList: Order[];
  currentOrder: Order;

  constructor() {
    this.orderList = new Array();
  }

  addNewOrder(orderType: string, ledger: Customer, tableId: number) {
    let order = new Order();
    order.Customer = ledger;
    order.Type = orderType;
    order.TableId = tableId;
    order.DisplayName = this.getDisplayName(orderType);
    this.orderList.push(order);

    this.currentOrder = order;

    console.log(this.orderList.length);
  }

  getCurrentOrder(): Order{
    return this.currentOrder;
  }

  getDisplayName(orderType: string){
    let displayName: string = '';
      if(orderType ==  'DineIn'){
        
      }
      else if(orderType ==  'Delivery'){

      }
      else if(orderType ==  'Takeaway'){

      }
      displayName = orderType;
      return displayName;
  }

  setCurrentOrder(displayName){
    this.orderList.forEach(element => {
      if(element.DisplayName == displayName){
        this.currentOrder = element;
      }
    });
  }

}
