import { Injectable } from '@angular/core';
import { HttpModule, Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable'
import { Category, Blog, Store, Order, Product, Ledger, Floor, Employee, Customer, PaymentMode, Configuration } from '../../models/model';
/*
  Generated class for the ApiProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/

const BASE_URL = 'http://api.ciferon.in/';

@Injectable()
export class ApiProvider {

  headers: Headers;
  options: RequestOptions;

  constructor(public http: Http) {
    this.headers = new Headers({ 'Authorization': 'Bearer xdP6pNp6ac9ELqju/vwteZT6fa/YxbiC2mEH2LpIdZOu5HPSmDjlg39+o/6b8/+aXljtVpvRvDfRiVHpa7Rc2rUzl+ij74anNAn40QP/PdJH9x1h0bI8EqRh0snLCxgToHcxVm2ivM+okJ+MB/P0KcSORahwg9UfVQcH6CI1CCM= ', 'CompanyId': '17', 'Content-Type': 'application/json', 'Accept': 'q=0.8;application/json;q=0.9' });
    this.options = new RequestOptions({ headers: this.headers });
  }

  //ORIGINAL IMPLEMENTATION
  // getProducts() : Observable<any>{
  //   return this.http.get('https://www.reddit.com/r/gifs/new/.json?limit=10').map(res => res.json())
  // }

  getProducts(): Observable<Category[]> {
    return this.http.get(BASE_URL + 'Api/POSV2Api/GetCategoryPOSList', this.options).map((res) => {
      return <Category[]>res.json().CategoryPOSListWrapper;
    });
  }

  getLocations(): Observable<Location[]> {
    return this.http.get(BASE_URL + 'AppApi/LocationAppApi/GetLocationList_App?storeid=1', this.options).map((res) => {
      return <Location[]>res.json().LocationAppListWrapper;
    });
  }

  getBlogs(): Observable<Blog[]> {
    return this.http.get(BASE_URL + 'AppApi/BlogAppApi/GetBlogList_App', this.options).map((res) => {
      return <Blog[]>res.json().BlogAppListWrapper;
    });
  }

  getStores(): Observable<Store[]> {
    return this.http.get(BASE_URL + 'AppApi/StoreAppApi/GetStoreList_App', this.options).map((res) => {
      return <Store[]>res.json().StoreAppListWrapper;
    });
  }

  getOrders(): Observable<Order[]> {
    return this.http.get(BASE_URL + 'AppApi/OrderAppApi/GetOrderList_App', this.options).map((res) => {
      return <Order[]>res.json().OrderAppListWrapper;
    });
  }

  getTodaySpecialProducts(): Observable<Product[]> {
    return this.http.get(BASE_URL + 'AppApi/TodaySpecialAppApi/GetTodaySpecialList_App', this.options).map((res) => {
      return <Product[]>res.json().TodaySpecialAppListWrapper;
    });
  }

  getCustomers(): Observable<Customer[]> {
    return this.http.get(BASE_URL + 'Api/POSV2Api/GetCustomerPOSList?storeId=1', this.options).map((res) => {
      return <Customer[]>res.json().CustomerPOSListWrapper;
    });
  }

  getFloors(): Observable<Floor[]> {
    return this.http.get(BASE_URL + 'Api/POSV2Api/GetFloorPOSList?storeId=1', this.options).map((res) => {
      return <Floor[]>res.json().FloorPOSListWrapper;
    });
  }

  getEmployees(): Observable<Employee[]> {
    return this.http.get(BASE_URL + 'Api/POSV2Api/GetEmployeePOSList?storeId=1', this.options).map((res) => {
      return <Employee[]>res.json().EmployeePOSListWrapper;
    });
  }

  getPaymentModes(): Observable<PaymentMode[]> {
    return this.http.get(BASE_URL + 'Api/POSV2Api/GetPaymentModePOSList?storeId=1', this.options).map((res) => {
      return <PaymentMode[]>res.json().PaymentModePOSListWrapper;
    });
  }

  getConfiguration(): Observable<Configuration> {
    return this.http.get(BASE_URL + 'Api/POSV2Api/GetConfigPOSList?storeId=1', this.options).map((res) => {
      return <Configuration>res.json();
    });
  }

  masterfetch(){
    
  }

}
