import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Ledger, Customer } from '../../models/model';
import { LocalStorageProvider } from '../../providers/storage/storage';
import { OrderProvider } from '../../providers/order/order';
import { HomePage } from '../home/home';

/**
 * Generated class for the CartPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-cart',
  templateUrl: 'cart.html',
})
export class CartPage {

  customersList: Customer[];
  searchString: string;
  newLedger: Ledger;
  tableId: number;
  orderType: string;

  constructor(public navCtrl: NavController, public navParams: NavParams, private order: OrderProvider, private storage: LocalStorageProvider) {
    this.orderType = this.navParams.get('orderType');
    this.tableId = this.navParams.get('tableId');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CartPage');
  }

  startOrder(customer: Customer) {
    this.createOrder(customer)
  }

  saveCustomer() {
    this.createOrder(null)
  }

  createOrder(customer: Customer) {
    this.order.addNewOrder(this.orderType, customer, this.tableId);
    this.navCtrl.push(HomePage);
  }

  searchCustomers(event: Event) {
    this.customersList = this.storage.getCustomers(this.searchString).slice(0, 5);
  }

}
