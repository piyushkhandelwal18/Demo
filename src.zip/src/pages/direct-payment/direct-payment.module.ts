import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DirectPaymentPage } from './direct-payment';

@NgModule({
  declarations: [
    DirectPaymentPage,
  ],
  imports: [
    IonicPageModule.forChild(DirectPaymentPage),
  ],
})
export class DirectPaymentPageModule {}
