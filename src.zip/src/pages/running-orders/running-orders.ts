import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { OrderProvider } from '../../providers/order/order';
import { Order } from '../../models/model';

/**
 * Generated class for the RunningOrdersPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-running-orders',
  templateUrl: 'running-orders.html',
})
export class RunningOrdersPage {

  orderList: Order[];

  constructor(public navCtrl: NavController, private navParams: NavParams, public orderProvider: OrderProvider) {
    this.orderList = orderProvider.orderList;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad RunningOrdersPage');
  }

  close(){
    this.navParams.get("parentPage").getCurrentOrder();
    this.navCtrl.pop();
  }

  setCurrentOrder(displayName: number){
    this.orderProvider.setCurrentOrder(displayName);
    this.close();
  }

}
