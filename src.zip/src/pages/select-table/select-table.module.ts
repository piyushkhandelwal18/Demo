import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SelectTablePage } from './select-table';

@NgModule({
  declarations: [
    SelectTablePage,
  ],
  imports: [
    IonicPageModule.forChild(SelectTablePage),
  ],
})
export class SelectTablePageModule {}
