import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Login } from '../../models/model';
import { ApiProvider } from '../../providers/api/api';

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  loginForm: FormGroup;
  submitAttempt: boolean = false;
  loginWrapper: Login;

  constructor(public navCtrl: NavController, public formBuilder: FormBuilder, private api: ApiProvider) {
    this.loginWrapper = new Login();
    this.loginForm = formBuilder.group({
      username: ['', Validators.compose([Validators.required])],
      password: ['', Validators.required]
    });
  }

  ionViewDidLoad() {
  }

  login() {
    this.navCtrl.setRoot('SelectStoresPage');
    // this.submitAttempt = true;
    // console.log(this.loginWrapper);
    // if (this.loginForm.valid) {
    //   this.navCtrl.setRoot('SelectStoresPage');
    // }
  }
}
