import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api';
import { Store, Floor, Customer, PaymentMode, Configuration, Employee, Category } from '../../models/model';
import { LocalStorageProvider } from '../../providers/storage/storage';

/**
 * Generated class for the SelectStoresPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-select-stores',
  templateUrl: 'select-stores.html',
})
export class SelectStoresPage {

  storeList: any
  index: number = 6;
  currentIndex = 0;
  
  constructor(public navCtrl: NavController, public navParams: NavParams, private api: ApiProvider, private storage: LocalStorageProvider) {
    this.storeList = navParams.get('storeList');
    console.log(this.storeList);
  }

  ionViewDidLoad() {
    //this.fetch();

  }

  public fetch() {
    // this.api.getStores().subscribe((customList: Store[]) => {
    //   this.storeList = customList;
    //   this.complete();
    // });

    this.api.getProducts().subscribe((customList: Category[]) => {
      this.storage.setCategoryList(customList);
      this.complete();
    });

    this.api.getFloors().subscribe((customList: Floor[]) => {
      this.storage.setFloorList(customList);
      this.complete();
    });

    this.api.getCustomers().subscribe((customList: Customer[]) => {
      this.storage.setCustomerList(customList);
      this.complete();
    });

    this.api.getPaymentModes().subscribe((customList: PaymentMode[]) => {
      this.storage.setPaymentModeList(customList);
      this.complete();
    });

    this.api.getConfiguration().subscribe((customList: Configuration) => {
      this.storage.setConfig(customList);
      this.complete();
    });

    this.api.getEmployees().subscribe((customList: Employee[]) => {
      this.storage.setEmployeeList(customList);
      this.complete();
    });
  }

  private complete(){
    this.currentIndex = this.currentIndex + 1;
    if(this.currentIndex == this.index){
      this.currentIndex = 0;
      this.navCtrl.push('SelectTablePage');
    }
    console.log(this.currentIndex);
  }

  showTableScreen() {
    
  }


}
