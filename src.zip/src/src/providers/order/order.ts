import { Injectable } from '@angular/core';
import { Ledger, Order, Customer } from '../../models/model';
import { LocalStorageProvider } from '../storage/storage';

/*
  Generated class for the OrderProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class OrderProvider {

  orderList: Order[];
  currentOrder: Order;

  constructor(private storage : LocalStorageProvider) {
    this.orderList = new Array();
  }

  addNewOrder(orderType: string, ledger: Customer, tableId: number) {
    let order = new Order();
    order.Customer = ledger;
    order.Type = orderType;
    order.TableId = tableId;
    order.DisplayName = this.getDisplayName(orderType, tableId);
    this.orderList.push(order);

    this.currentOrder = order;

    console.log(this.orderList.length);
  }

  getCurrentOrder(): Order{
    return this.currentOrder;
  }

  getDisplayName(orderType: string, tableId: number){
    let displayName: string = '';
      if(orderType ==  'DineIn'){
        displayName = this.storage.getTableNumber(tableId);
      }
      else if(orderType ==  'Delivery'){
        displayName = 'Del'
      }
      else if(orderType ==  'Takeaway'){
        displayName = 'Take'
      }
      return displayName;
  }

  setCurrentOrder(displayName){
    this.orderList.forEach(element => {
      if(element.DisplayName == displayName){
        this.currentOrder = element;
      }
    });
  }

}
