import { Injectable } from '@angular/core';
import { Category, Product, Ledger, Floor, Employee, Configuration, Customer, PaymentMode } from '../../models/model';
/*
  Generated class for the StorageProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class LocalStorageProvider {


  categoryList: Category[];
  customerList: Customer[];
  config: Configuration;
  paymentModeList: PaymentMode[];
  employeeList: Employee[];
  floorList: Floor[];

  constructor() {

  }

  get FloorList() {
    return this.floorList;
  }

  getTableNumber(tableId) {
    for (var floor = 0; floor < this.floorList.length; floor++) {
      for (var table = 0; table < this.floorList[floor].TableList.length; table++) {
        if (tableId == this.floorList[floor].TableList[table].TableId) {
          return this.floorList[floor].FloorName + ' ' + this.floorList[floor].TableList[table].TableName;
        }
      }
    }
  }

  setCategoryList(categoryList: Category[]) {
    this.categoryList = categoryList;
  }

  searchProducts(searchString: string): Product[] {
    let productList: Product[] = new Array();
    this.categoryList.forEach(element => {
      element.ProductList.forEach(product => {
        if (product.ProductName.search(searchString) == -1) {
          productList.push(product);
        }
      });
    });
    return productList;
  }


  setCustomerList(customerList: Customer[]) {
    this.customerList = customerList;
  }

  getCustomers(searchString: string): Customer[] {
    let ledgerResults: Customer[] = new Array();
    this.customerList.forEach(element => {
      if (element.CustomerName != null && element.CustomerName.search(searchString) != -1) {
        ledgerResults.push(element);
      }
      else if (element.CustomerMobileNo != null && element.CustomerMobileNo.search(searchString) != -1) {
        ledgerResults.push(element);
      }
    });
    return ledgerResults;
  }

  setFloorList(floorList: Floor[]) {
    this.floorList = floorList;
  }

  setEmployeeList(floorList: Employee[]) {
    this.employeeList = floorList;
  }

  setPaymentModeList(floorList: PaymentMode[]) {
    this.paymentModeList = floorList;
  }

  setConfig(floorList: Configuration) {
    this.config = floorList;
  }
}
