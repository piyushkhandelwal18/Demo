export class Category {
    CategoryId: number = 0;
    CategoryName: string = '';
    ImgUrl: string;
    ProductList: Product[];
}

export interface ICategory {
    CategoryId: number;
    CategoryName: string;
    ImgUrl: string;
    ProductList: Product[];
}

export class ComboGroup {
    Name: string;
    AllowedQty: string;
    ComboList: Product[];
}

export class Product {
    ProductId: number = 0;
    ProductName: string = '';
    MinSalePrice: number = 0;
    IsAddon: boolean;
    IsSelected: boolean = false;
    AddOnList: Product[];
    ComboGroupList: ComboGroup[];
    hasProduct = this.hasCustomization;

    get total() {
        return 100;
    }

    get hasCustomization() {
        // if(this.AddOnList != undefined && this.AddOnList.length > 0){
        //     return true;
        // }
        // else if(this.ComboGroupList != undefined && this.ComboGroupList.length > 0){
        //     return true;
        // }
        // else{
        //     return false;
        // }
        return true;
    }
}

export class User {

}

export class Order {
    OrderID: number;
    OrderSerialNo: string;
    Source: string;
    PurchaseDate: Date;
    GrandTotal: number;
    OrderItemAppListWrapper: OrderItem[];
    Customer: Customer;
    Type: string;
    TableId: number;
    DisplayName: string;
}

export class OrderItem {
    OrderItem: number;
    ProductId: number;
    Product: Product;
    Quantity: number;
    UniqueId: number;
    CustomizeText: string;
    AddOnList: Product[];


    constructor() {

    }


}

export interface Blog {
    BlogId: number;
    Heading?: any;
    Description: string;
    ImageUrl: string;
}

export class Location {
    LocationId: number;
    AreaName: string;
    PinCode: string;
}

export class Store {
    StoreID: number;
    StoreName: string;
    ContactNo: string;
    IsActive: boolean;
    IsDeleted: boolean;
    IsAvailableInPOS: boolean;
    StoreNo: string;
    EmailID: string;
    PaymentModeIds: string;
    ExpireyDate: string;
    HeaderContent: string;
    FooterContent: string;
    PaymentIds: string;
    GSTNO: any;
    LedgerId: number;
    AddressId: number;
    IsStore: boolean;
    StoreList: any;
    LedgerList: any;
    PaymentList: any;
    LedgerName: any;
    PinCode: any;
    PaymentModeList: any[];
    CreatedBy: any;
    CreatedOn: string;
    ModifiedBy: any;
    ModifiedOn: string;
    CreatedByUser: number;
    ModifiedByUser: number;
}

export class CategoryAppListWrapper {
    CategoryList: Category[];
}

export class Ledger {
    LedgerId: number;
    LedgerName: string;
}

export class Floor {
    FloorId: number;
    FloorName: string;
    IsActive: boolean;
    TableList: Table[];
}

export class Table {
    TableId: number;
    TableName: string;
    Pax: any;
    IsActive: boolean;
    FloorId: number;
    IsTableReserved: boolean;
    StoreId: number;
}

export class Employee {
    EmployeeId: number;
    EmployeeName: string;
}

export class Customer {
    CustomerId: number;
    CustomerName: string;
    CustomerMobileNo: string;
}

export class PaymentMode {
    PaymentModeId: number;
    PaymentType: string;
    IsSelected: boolean;
}

export class Configuration {
    Store: Store;
    LastKOTNo: string;
    HomeDeliveryNo: string;
    TakeAwayNo: string;
    DineInNo: string;
    OrderSerialNo: string;
    KOTNoSuffix: string;
    DineInNoSuffix: string;
    TakeAwayNoSuffix: string;
    HomeDeliveryNoSuffix: string;
    OrderSerialNoSuffix: string;
    OrderType: string;
}

export class Login {
    ErrorMessage: string;
    UserName: string;
    Password: string;
    AuthKey: string;
}

export class PaymentNote {
    Payment: PaymentMode;
    Amount: number;
}

