import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ApiProvider } from '../../providers/api/api';
import { Blog } from '../../models/model';

/**
 * Generated class for the BlogPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-blog',
  templateUrl: 'blog.html',
})
export class BlogPage {

  blogList: Blog[];

  constructor(public navCtrl: NavController, public api: ApiProvider) {
    api.getBlogs().subscribe((customList: Blog[]) => {
      this.blogList = customList;
      console.log(this.blogList);
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad BlogPage');
  }

}
