import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BlogPage } from './blog';
import { SuperTabsModule } from 'ionic2-super-tabs';

@NgModule({
  declarations: [
    BlogPage,
  ],
  imports: [
    IonicPageModule.forChild(BlogPage),
    SuperTabsModule,
  ],
})
export class BlogPageModule {}
