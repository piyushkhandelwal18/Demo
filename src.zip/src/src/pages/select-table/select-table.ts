import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, PopoverController } from 'ionic-angular';
import { HomePage } from '../home/home';
import { LocalStorageProvider } from '../../providers/storage/storage';
import { ProductlistPage } from '../productlist/productlist';
import { SuperTabsModule, SuperTabs } from 'ionic2-super-tabs';
import { ApiProvider } from '../../providers/api/api';
import { Floor, Table } from '../../models/model';
/**
 * Generated class for the SelectTablePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-select-table',
  templateUrl: 'select-table.html',
})
export class SelectTablePage {

  floorList: Floor[];
  tableList: Table[];

  constructor(public navCtrl: NavController, public navParams: NavParams, public popoverCtrl: PopoverController, private storage: LocalStorageProvider) {
    this.floorList = storage.FloorList;
    this.tableList = this.floorList[0].TableList;
  }

  ionViewDidLoad() {
  }

  changeTables(tableList: Table[]) {
    this.tableList = tableList;
  }

  selectTable(tableId: number) {
    console.log(tableId);
    this.showCustomerPopup('DineIn', tableId);
  }

  startDeliveryOrder() {
    this.showCustomerPopup('Delivery', 0);
  }

  startTakeawayOrder() {
    this.showCustomerPopup('Takeaway', 0);
  }

  private showCustomerPopup(orderType: string, tableId: number) {
    let popover = this.popoverCtrl.create('CartPage', { orderType: orderType, tableId: tableId });
    popover.present();
  }

}
