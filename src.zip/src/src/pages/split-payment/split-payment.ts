import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { LocalStorageProvider } from '../../providers/storage/storage';
import { PaymentMode, PaymentNote } from '../../models/model';

/**
 * Generated class for the SplitPaymentPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-split-payment',
  templateUrl: 'split-payment.html',
})
export class SplitPaymentPage {

  paymentModeList : PaymentMode[];
  paymentNoteList : PaymentNote[];
  addedPayment: number;
  constructor(public navCtrl: NavController, private storage: LocalStorageProvider) {
    this.paymentModeList = storage.paymentModeList;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SplitPaymentPage');
  }

  addPaymentNote(payment: PaymentMode){
    if(this.addedPayment != undefined && this.addedPayment > 0){

    }
    else{
      if(this.paymentNoteList == undefined){
        this.paymentNoteList = new Array();
      }
      let note = new PaymentNote();
      note.Payment = payment;
      note.Amount = this.addedPayment;
      this.paymentNoteList.push(note);
    }
  }

  removePaymentNote(payment: PaymentNote){
    
  }
}
