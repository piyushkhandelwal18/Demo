import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, PopoverController } from 'ionic-angular';
import { ProductlistPage } from '../productlist/productlist';
import { Category, Store, Location, Product } from '../../models/model';
import { Http } from '@angular/http';
import { ApiProvider } from '../../providers/api/api';
import { HomePage } from '../home/home';
import { AddonPage } from '../addon/addon';

/**
 * Generated class for the CatalogPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-catalog',
  templateUrl: 'catalog.html',
})
export class CatalogPage {

  tabRoot1: any = ProductlistPage;
  categoryList: Category[];
  todaySpecialList : Product[];

  constructor(public navCtrl: NavController, private api: ApiProvider, public popoverCtrl: PopoverController) {

    this.api.getProducts().subscribe((customList: Category[]) => {
      this.categoryList = customList;
    });

    this.api.getTodaySpecialProducts().subscribe((customList: Product[]) => {
      this.todaySpecialList = customList;
    });

    this.api.getStores().subscribe((customList: Store[]) => {
      let popover = this.popoverCtrl.create('SelectStoresPage', {storeList: customList});
      popover.present();
    });
  }

  showProducts(id: number) {
    this.navCtrl.push(HomePage, { id: id });
  }

}
