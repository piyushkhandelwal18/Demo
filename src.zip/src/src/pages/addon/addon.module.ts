import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddonPage } from './addon';

@NgModule({
  declarations: [
    AddonPage,
  ],
  imports: [
    IonicPageModule.forChild(AddonPage),
  ],
})
export class AddonPageModule {}
