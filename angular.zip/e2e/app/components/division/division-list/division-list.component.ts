import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-division-list',
  templateUrl: './division-list.component.html',
  styleUrls: ['./division-list.component.css']
})
export class DivisionListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
