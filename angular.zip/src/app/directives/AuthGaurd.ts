import { CanActivate, CanActivateChild, Router } from "@angular/router";

export class AuthGuard implements CanActivate, CanActivateChild {
  constructor(private router: Router) { }

  canActivate() {
    
    return false;
  }

  canActivateChild() {
    
    return false;
  }

  private getAuthKey(){
    
  }
}