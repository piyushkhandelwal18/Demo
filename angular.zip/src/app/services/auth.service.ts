import { Injectable } from '@angular/core';

@Injectable()
export class AuthService {

  constructor() { }

  getAuthKey(){
    return localStorage.getItem('authkey');
  }

  setAuthKey(authkey : string){
    localStorage.setItem('authkey', authkey);
  }
}
