import { Injectable } from '@angular/core';
import { LoginRequest, LoginResponse } from '../models/login';

import { map } from 'rxjs/operators'
import { Category } from '../models/category';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { error } from 'protractor';



@Injectable()
export class ApiService {

  BASE_URL = 'http://api.ciferon.in/';

  constructor(private http: HttpClient) { }

  login(loginRequest: LoginRequest) {
    return this.http.post(this.BASE_URL + 'Api/LoginApi/Post', loginRequest);
  }

  getProductModuleList(type:string){
    return this.http.get(this.BASE_URL + 'Api/ProductApi/Get?type=' + type);
  }

}
