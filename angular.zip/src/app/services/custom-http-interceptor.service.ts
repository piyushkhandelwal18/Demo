import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpEvent, HttpRequest, HttpErrorResponse, HttpResponse, HttpEventType } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { map, catchError } from 'rxjs/operators';
import { error } from 'protractor';
import { tap } from 'rxjs/operators';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class CustomHttpInterceptorService implements HttpInterceptor {

  constructor(private router: Router, private auth: AuthService) { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    request = request.clone({
      setHeaders: {
        Authorization: 'Bearer ' + this.auth.getAuthKey()
      }
    });

    console.log(localStorage.getItem('authkey'));
    return next.handle(request).pipe(map(data => data), catchError(this.handleError));;
  }

  private handleError(err: HttpErrorResponse): Observable<any> {
    console.log(err.status);
    if (err.status === 401 || err.status === 403) {
      this.router.navigateByUrl(`/`);
    }
    return Observable.throw(err);
  }
}
