import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  isSideBarVisible = true;
  isProductModuleActive = false;
  isAccountModuleActive = false;
  isReportModuleActive = false;
  isCompanyModuleActive = false;
  isInventoryModuleActive = false;

  constructor(private _router: Router) { }

  showNavbar() {
    this.isSideBarVisible = !this.isSideBarVisible;
    //this.isSideBarVisible = false;
  }

  changeModule(module: String){
    this.isProductModuleActive = false;
    this.isAccountModuleActive = false;
    this.isReportModuleActive = false;
    this.isCompanyModuleActive = false;
    this.isInventoryModuleActive = false;

    if(module == 'product'){
      this.isProductModuleActive = true;
      this._router.navigate(['product']);
    }
    else if(module == 'account'){
      this.isAccountModuleActive = true;
      this._router.navigate(['account']);
    }
    else if(module == 'company'){
      this.isCompanyModuleActive = true;
      this._router.navigate(['company']);
    }
    else if(module == 'report'){
      this.isReportModuleActive = true;
      this._router.navigate(['report']);
    }
    else if(module == 'inventory'){
      this.isInventoryModuleActive = true;
      this._router.navigate(['inventory']);
    }
  }
}
