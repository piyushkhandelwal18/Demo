export class LoginRequest {
    public Username: string;
    public Password: string;
}

export class LoginResponse {
    public Status: string;
    public AuthKey: string;
    public ErrorMessage : string;
}