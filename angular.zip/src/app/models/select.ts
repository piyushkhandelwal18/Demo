export class SelectItem {
    Value: string;
    Text: string

    /**
     *
     */
    constructor(text :string, value: string) {
        

    }
}
