export class Category {
     CategoryName: string
     Description: string
     IsActive: boolean
}