export class ApiResponse{
    public Status: string;
    public Result: any;
}