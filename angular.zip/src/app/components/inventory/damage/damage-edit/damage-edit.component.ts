import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-damage-edit',
  templateUrl: './damage-edit.component.html',
  styleUrls: ['./damage-edit.component.css']
})
export class DamageEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
