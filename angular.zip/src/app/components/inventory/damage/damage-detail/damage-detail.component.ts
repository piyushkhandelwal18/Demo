import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-damage-detail',
  templateUrl: './damage-detail.component.html',
  styleUrls: ['./damage-detail.component.css']
})
export class DamageDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
