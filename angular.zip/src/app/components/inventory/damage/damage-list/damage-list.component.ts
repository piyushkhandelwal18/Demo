import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-damage-list',
  templateUrl: './damage-list.component.html',
  styleUrls: ['./damage-list.component.css']
})
export class DamageListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
