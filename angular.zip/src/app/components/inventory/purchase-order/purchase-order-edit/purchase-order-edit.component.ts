import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchase-order-edit',
  templateUrl: './purchase-order-edit.component.html',
  styleUrls: ['./purchase-order-edit.component.css']
})
export class PurchaseOrderEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
