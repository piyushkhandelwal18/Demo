import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchase-order-list',
  templateUrl: './purchase-order-list.component.html',
  styleUrls: ['./purchase-order-list.component.css']
})
export class PurchaseOrderListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
