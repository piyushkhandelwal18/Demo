import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchase-invoice-list',
  templateUrl: './purchase-invoice-list.component.html',
  styleUrls: ['./purchase-invoice-list.component.css']
})
export class PurchaseInvoiceListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
