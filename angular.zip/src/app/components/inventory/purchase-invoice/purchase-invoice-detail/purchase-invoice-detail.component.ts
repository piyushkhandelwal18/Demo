import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchase-invoice-detail',
  templateUrl: './purchase-invoice-detail.component.html',
  styleUrls: ['./purchase-invoice-detail.component.css']
})
export class PurchaseInvoiceDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
