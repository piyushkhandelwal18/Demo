import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-transfer-detail',
  templateUrl: './stock-transfer-detail.component.html',
  styleUrls: ['./stock-transfer-detail.component.css']
})
export class StockTransferDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
