import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-transfer-list',
  templateUrl: './stock-transfer-list.component.html',
  styleUrls: ['./stock-transfer-list.component.css']
})
export class StockTransferListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
