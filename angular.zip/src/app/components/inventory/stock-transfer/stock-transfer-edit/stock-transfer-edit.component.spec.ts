import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StockTransferEditComponent } from './stock-transfer-edit.component';

describe('StockTransferEditComponent', () => {
  let component: StockTransferEditComponent;
  let fixture: ComponentFixture<StockTransferEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StockTransferEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StockTransferEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
