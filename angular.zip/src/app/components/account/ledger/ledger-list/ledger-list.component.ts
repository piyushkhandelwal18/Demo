import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ledger-list',
  templateUrl: './ledger-list.component.html',
  styleUrls: ['./ledger-list.component.css']
})
export class LedgerListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
