import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ledger-edit',
  templateUrl: './ledger-edit.component.html',
  styleUrls: ['./ledger-edit.component.css']
})
export class LedgerEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
