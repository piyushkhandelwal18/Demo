import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ledger-detail',
  templateUrl: './ledger-detail.component.html',
  styleUrls: ['./ledger-detail.component.css']
})
export class LedgerDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
