import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ledger-group-detail',
  templateUrl: './ledger-group-detail.component.html',
  styleUrls: ['./ledger-group-detail.component.css']
})
export class LedgerGroupDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
