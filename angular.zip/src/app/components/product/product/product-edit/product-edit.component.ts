import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
//import { Product } from '../../../../models/product';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { TemplateRef } from '@angular/core';
import { SelectItem } from '../../../../models/select';

@Component({
  selector: 'app-product-edit',
  templateUrl: './product-edit.component.html',
  styleUrls: ['./product-edit.component.css']
})
export class ProductEditComponent implements OnInit {

  editform: FormGroup;
  submitted = false;
  productSelectList : SelectItem[];
    
  constructor(private modalService: BsModalService) { 
    
  }

  ngOnInit() {
    this.productSelectList = new Array<SelectItem>();
    this.productSelectList.push(new SelectItem('ABC1', 'abc1'));
    this.productSelectList.push(new SelectItem('ABC2', 'abc2'));
    this.productSelectList.push(new SelectItem('ABC3', 'abc3'));
    this.productSelectList.push(new SelectItem('ABC4', 'abc4'));
    this.productSelectList.push(new SelectItem('ABC5', 'abc5'));
    this.productSelectList.push(new SelectItem('ABC6', 'abc6'));
    console.log(this.productSelectList);
  }
  
  modalRef: BsModalRef;
  message: string;
  imageUrl: string;
 
  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(ProductEditComponent, {class: 'modal-lg'});
  }
 
  confirm(): void {
    this.message = 'Confirmed!';
    this.modalRef.hide();
  }
 
  decline(): void {
    this.message = 'Declined!';
    this.modalRef.hide();
  }

  onImageSelected(imageStr: string){
    console.log('djkbcvjk' + imageStr);
  }

}
