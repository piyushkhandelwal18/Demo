import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Category } from '../../../../models/category';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { TemplateRef } from '@angular/core';

@Component({
    selector: 'app-category-edit',
    templateUrl: './category-edit.component.html',
    styleUrls: ['./category-edit.component.css']
})
export class CategoryEditComponent implements OnInit {

    editform: FormGroup;
    submitted = false;
    cat: Category;

    constructor(private formBuilder: FormBuilder, private modalService: BsModalService) { }

    ngOnInit() {
        this.editform = this.formBuilder.group({
            name: ['', Validators.required]
        });
    }

    // convenience getter for easy access to form fields
    get f() { return this.editform.controls; }

    onSubmit() {
        this.submitted = true;

        // stop here if form is invalid
        if (this.editform.valid) {
            var values = this.editform.getRawValue();
            this.cat = new Category();
            this.cat.CategoryName = values.name;
            console.log(this.cat);
        }

    }


    modalRef: BsModalRef;
  message: string;
  
 
  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(CategoryEditComponent, {class: 'modal-lg'});
  }
 
  confirm(): void {
    this.message = 'Confirmed!';
    this.modalRef.hide();
  }
 
  decline(): void {
    this.message = 'Declined!';
    this.modalRef.hide();
  }
}
