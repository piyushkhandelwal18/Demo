import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-combo-list',
  templateUrl: './combo-list.component.html',
  styleUrls: ['./combo-list.component.css']
})
export class ComboListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
