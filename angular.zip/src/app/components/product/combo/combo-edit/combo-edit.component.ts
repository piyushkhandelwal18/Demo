import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-combo-edit',
  templateUrl: './combo-edit.component.html',
  styleUrls: ['./combo-edit.component.css']
})
export class ComboEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
