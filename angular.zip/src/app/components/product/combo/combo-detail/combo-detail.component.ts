import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-combo-detail',
  templateUrl: './combo-detail.component.html',
  styleUrls: ['./combo-detail.component.css']
})
export class ComboDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
