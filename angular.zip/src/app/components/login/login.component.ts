import { Component, OnInit } from '@angular/core';
import { LoginRequest, LoginResponse } from '../../models/login';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import { StorageService } from '../../services/storage.service';
import { RouterService } from '../../services/router.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login: LoginRequest = new LoginRequest();
  loginForm: FormGroup;
  username: FormControl;
  password: FormControl;

  constructor(private _api: ApiService, private _storage: StorageService,
    private route: RouterService, private auth: AuthService) { }


  ngOnInit() {
    var authKey = this.auth.getAuthKey();
    if (authKey != null && authKey != null) {
      this.route.redirectToMain();
    }

    this.username = new FormControl('', [
      Validators.required
    ]);

    this.password = new FormControl('', Validators.required);

    this.loginForm = new FormGroup({ username: this.username, password: this.password });
  }

  doLogin() {
    if (this.loginForm.valid) {
      this._api.login(this.login).subscribe((data: LoginResponse) => {
        if (data.Status == 'Success') {
          this._storage.saveLoginResponse(data);
          this.route.redirectToMain();
        }
      });
    }
  }
}
