import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent implements OnInit {

  @Input() imageUrl: string;
  @Output() onImageSelected = new EventEmitter<string>();

  constructor() { }

  ngOnInit() {
    console.log('dedqwed' + this.imageUrl);
  }

  readUrl(event:any) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
  
      reader.onload = (event:any) => {
        this.imageUrl = event.target.result;
        this.onImageSelected.emit(event.target.result);
      }
      
      reader.readAsDataURL(event.target.files[0]);
    }
  }

}
