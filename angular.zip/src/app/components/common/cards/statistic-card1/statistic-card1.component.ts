import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-statistic-card1',
  templateUrl: './statistic-card1.component.html',
  styleUrls: ['./statistic-card1.component.css']
})
export class StatisticCard1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
