import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-header',
  templateUrl: './company-header.component.html',
  styleUrls: ['./company-header.component.css']
})
export class CompanyHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
