import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-header',
  templateUrl: './report-header.component.html',
  styleUrls: ['./report-header.component.css']
})
export class ReportHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
