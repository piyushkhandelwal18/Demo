import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inventory-header',
  templateUrl: './inventory-header.component.html',
  styleUrls: ['./inventory-header.component.css']
})
export class InventoryHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
