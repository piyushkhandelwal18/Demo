import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { ReportDashboardComponent } from './components/report/report-dashboard/report-dashboard.component';
import { AccountDashboardComponent } from './components/account/account-dashboard/account-dashboard.component';
import { CompanyDashboardComponent } from './components/company/company-dashboard/company-dashboard.component';
import { LoginComponent } from './components/login/login.component';
import { Routes, RouterModule, Router } from '@angular/router';
import { ROUTING } from './app.routing';
import { ProductDashboardComponent } from './components/product/product-dashboard/product-dashboard.component';
import { InventoryDashboardComponent } from './components/inventory/inventory-dashboard/inventory-dashboard.component';
import { CategoryListComponent } from './components/Product/category/category-list/category-list.component';
import { CategoryDetailComponent } from './components/Product/Category/category-detail/category-detail.component';
import { CategoryEditComponent } from './components/Product/Category/category-edit/category-edit.component';
import { ProductListComponent } from './components/Product/product/product-list/product-list.component';
import { ProductDetailComponent } from './components/Product/Product/product-detail/product-detail.component';
import { ProductEditComponent } from './components/Product/Product/product-edit/product-edit.component';
import { RecipeEditComponent } from './components/Product/recipe/recipe-edit/recipe-edit.component';
import { RecipeListComponent } from './components/Product/Recipe/recipe-list/recipe-list.component';
import { RecipeDetailComponent } from './components/Product/Recipe/recipe-detail/recipe-detail.component';
import { UnitEditComponent } from './components/Product/unit/unit-edit/unit-edit.component';
import { UnitDetailComponent } from './components/Product/Unit/unit-detail/unit-detail.component';
import { UnitListComponent } from './components/Product/Unit/unit-list/unit-list.component';
import { ComboListComponent } from './components/Product/combo/combo-list/combo-list.component';
import { ComboDetailComponent } from './components/Product/Combo/combo-detail/combo-detail.component';
import { ComboEditComponent } from './components/Product/Combo/combo-edit/combo-edit.component';
import { LedgerGroupEditComponent } from './components/Account/ledger-group/ledger-group-edit/ledger-group-edit.component';
import { LedgerGroupDetailComponent } from './components/Account/ledger-group/ledger-group-detail/ledger-group-detail.component';
import { LedgerGroupListComponent } from './components/Account/ledger-group/ledger-group-list/ledger-group-list.component';
import { LedgerListComponent } from './components/Account/ledger/ledger-list/ledger-list.component';
import { LedgerDetailComponent } from './components/Account/Ledger/ledger-detail/ledger-detail.component';
import { LedgerEditComponent } from './components/Account/Ledger/ledger-edit/ledger-edit.component';
import { ExpenseEditComponent } from './components/Account/expense/expense-edit/expense-edit.component';
import { ExpenseDetailComponent } from './components/Account/Expense/expense-detail/expense-detail.component';
import { ExpenseListComponent } from './components/Account/Expense/expense-list/expense-list.component';
import { PurchaseInvoiceListComponent } from './components/Inventory/purchase-invoice/purchase-invoice-list/purchase-invoice-list.component';
import { PurchaseInvoiceDetailComponent } from './components/Inventory/purchase-invoice/purchase-invoice-detail/purchase-invoice-detail.component';
import { PurchaseInvoiceEditComponent } from './components/Inventory/purchase-invoice/purchase-invoice-edit/purchase-invoice-edit.component';
import { PurchaseOrderEditComponent } from './components/Inventory/purchase-order/purchase-order-edit/purchase-order-edit.component';
import { PurchaseOrderDetailComponent } from './components/Inventory/purchase-order/purchase-order-detail/purchase-order-detail.component';
import { PurchaseOrderListComponent } from './components/Inventory/purchase-order/purchase-order-list/purchase-order-list.component';
import { StockTransferListComponent } from './components/Inventory/stock-transfer/stock-transfer-list/stock-transfer-list.component';
import { StockTransferEditComponent } from './components/Inventory/stock-transfer/stock-transfer-edit/stock-transfer-edit.component';
import { StockTransferDetailComponent } from './components/Inventory/stock-transfer/stock-transfer-detail/stock-transfer-detail.component';
import { StockStatusListComponent } from './components/Inventory/stock-status/stock-status-list/stock-status-list.component';
import { DamageListComponent } from './components/Inventory/damage/damage-list/damage-list.component';
import { DamageDetailComponent } from './components/Inventory/Damage/damage-detail/damage-detail.component';
import { DamageEditComponent } from './components/Inventory/Damage/damage-edit/damage-edit.component';
import { ProductHeaderComponent } from './components/common/headers/product-header/product-header.component';
import { AccountHeaderComponent } from './components/common/headers/account-header/account-header.component';
import { InventoryHeaderComponent } from './components/common/headers/inventory-header/inventory-header.component';
import { ReportHeaderComponent } from './components/common/headers/report-header/report-header.component';
import { CompanyHeaderComponent } from './components/common/headers/company-header/company-header.component';
import { MainDashboardComponent } from './components/main/main-dashboard/main-dashboard.component';
import { BackButtonComponent } from './components/common/buttons/back-button/back-button.component';
import { StatisticCard1Component } from './components/common/cards/statistic-card1/statistic-card1.component';
import { ListHeaderComponent } from './components/common/headers/list-header/list-header.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TableLoaderComponent } from './components/common/loaders/table-loader/table-loader.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ApiService } from './services/api.service';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { DbService } from './services/db.service';
import { StorageService } from './services/storage.service';
import { DivisionListComponent } from './components/product/division/division-list/division-list.component';
import { MatButtonModule, MatCardModule, MatMenuModule, MatToolbarModule, MatIconModule, MatSidenav, MatSidenavModule, MatTableModule, MatPaginatorModule, MatCheckbox, MatCheckboxModule, MatRadioButton, MatFormFieldModule, MatOptionModule, MatSelectModule, MatInputModule } from '@angular/material';
import { CustomHttpInterceptorService } from './services/custom-http-interceptor.service';
import { AuthService } from './services/auth.service';
import { BsModalService, ModalModule } from 'ngx-bootstrap/modal';
import { FileUploadComponent } from './components/common/buttons/file-upload/file-upload.component';

@NgModule({
  declarations: [
    AppComponent,
    ReportDashboardComponent,
    AccountDashboardComponent,
    CompanyDashboardComponent,
    ProductDashboardComponent,
    InventoryDashboardComponent,
    LoginComponent,
    CategoryListComponent,
    CategoryDetailComponent,
    CategoryEditComponent,
    ProductListComponent,
    ProductDetailComponent,
    ProductEditComponent,
    RecipeEditComponent,
    RecipeListComponent,
    RecipeDetailComponent,
    UnitEditComponent,
    UnitDetailComponent,
    UnitListComponent,
    ComboListComponent,
    ComboDetailComponent,
    ComboEditComponent,
    LedgerGroupEditComponent,
    LedgerGroupDetailComponent,
    LedgerGroupListComponent,
    LedgerListComponent,
    LedgerDetailComponent,
    LedgerEditComponent,
    ExpenseEditComponent,
    ExpenseDetailComponent,
    ExpenseListComponent,
    PurchaseInvoiceListComponent,
    PurchaseInvoiceDetailComponent,
    PurchaseInvoiceEditComponent,
    PurchaseOrderEditComponent,
    PurchaseOrderDetailComponent,
    PurchaseOrderListComponent,
    StockTransferListComponent,
    StockTransferEditComponent,
    StockTransferDetailComponent,
    StockStatusListComponent,
    DamageListComponent,
    DamageDetailComponent,
    DamageEditComponent,
    ProductHeaderComponent,
    AccountHeaderComponent,
    InventoryHeaderComponent,
    ReportHeaderComponent,
    CompanyHeaderComponent,
    MainDashboardComponent,
    BackButtonComponent,
    StatisticCard1Component,
    ListHeaderComponent,
    TableLoaderComponent,
    CategoryEditComponent,
    DivisionListComponent,
    FileUploadComponent,
  ],
  imports: [
    BrowserModule, ROUTING, BrowserAnimationsModule, FormsModule, ReactiveFormsModule, HttpClientModule,
    BrowserAnimationsModule, ModalModule.forRoot(),
    MatButtonModule, MatCardModule, MatMenuModule, MatToolbarModule, MatIconModule, MatSidenavModule, MatTableModule,
    MatPaginatorModule, MatCheckboxModule, MatFormFieldModule, MatOptionModule, MatSelectModule, MatInputModule
  ],
  providers: [ApiService, StorageService, DbService, AuthService, BsModalService,{
    provide: HTTP_INTERCEPTORS,
    useClass: CustomHttpInterceptorService,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
