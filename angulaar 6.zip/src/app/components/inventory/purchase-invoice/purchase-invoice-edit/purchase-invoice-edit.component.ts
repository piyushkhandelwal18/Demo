import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchase-invoice-edit',
  templateUrl: './purchase-invoice-edit.component.html',
  styleUrls: ['./purchase-invoice-edit.component.css']
})
export class PurchaseInvoiceEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
