import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-status-list',
  templateUrl: './stock-status-list.component.html',
  styleUrls: ['./stock-status-list.component.css']
})
export class StockStatusListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
