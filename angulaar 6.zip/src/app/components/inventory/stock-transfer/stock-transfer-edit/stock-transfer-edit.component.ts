import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-transfer-edit',
  templateUrl: './stock-transfer-edit.component.html',
  styleUrls: ['./stock-transfer-edit.component.css']
})
export class StockTransferEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
