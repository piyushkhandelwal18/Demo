import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LedgerGroupDetailComponent } from './ledger-group-detail.component';

describe('LedgerGroupDetailComponent', () => {
  let component: LedgerGroupDetailComponent;
  let fixture: ComponentFixture<LedgerGroupDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LedgerGroupDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LedgerGroupDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
