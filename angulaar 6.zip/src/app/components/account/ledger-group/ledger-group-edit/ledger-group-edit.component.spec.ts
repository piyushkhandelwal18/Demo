import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LedgerGroupEditComponent } from './ledger-group-edit.component';

describe('LedgerGroupEditComponent', () => {
  let component: LedgerGroupEditComponent;
  let fixture: ComponentFixture<LedgerGroupEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LedgerGroupEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LedgerGroupEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
