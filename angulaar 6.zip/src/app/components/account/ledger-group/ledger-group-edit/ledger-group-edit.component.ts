import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ledger-group-edit',
  templateUrl: './ledger-group-edit.component.html',
  styleUrls: ['./ledger-group-edit.component.css']
})
export class LedgerGroupEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
