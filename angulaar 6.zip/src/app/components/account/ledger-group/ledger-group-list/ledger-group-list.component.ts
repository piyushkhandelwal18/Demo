import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ledger-group-list',
  templateUrl: './ledger-group-list.component.html',
  styleUrls: ['./ledger-group-list.component.css']
})
export class LedgerGroupListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
