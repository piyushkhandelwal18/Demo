import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unit-edit',
  templateUrl: './unit-edit.component.html',
  styleUrls: ['./unit-edit.component.css']
})
export class UnitEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
