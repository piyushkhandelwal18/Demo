import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unit-detail',
  templateUrl: './unit-detail.component.html',
  styleUrls: ['./unit-detail.component.css']
})
export class UnitDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
