import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-list-header',
  templateUrl: './list-header.component.html',
  styleUrls: ['./list-header.component.css']
})
export class ListHeaderComponent implements OnInit {

  @Input() type: string;
  listHeaders: ListHeader[];
  header: ListHeader;

  constructor() { }

  ngOnInit() {
    this.listHeaders = new Array<ListHeader>();
    this.listHeaders.push(new ListHeader('category', 'Products', 'Categories', 'New Category', 'categoryedit'));
    this.header = this.getListHeader(this.type);
  }

  getListHeader(name: string): ListHeader {
    for (let index = 0; index < this.listHeaders.length; index++) {
      const element = this.listHeaders[index];
      if (element.Name == name) {
        console.log(element);
        return element;
      }
    }
  }
}

export class ListHeader {
  Name: String;
  Headname: string;
  ButtonText: string;
  Title: string;
  Url: string;

  /**
   *
   */
  constructor(Name: String, Headname: string, ButtonText: string, Title: string, Url: string) {
    this.Name = name;
    this.ButtonText = ButtonText;
    this.Title = Title;
    this.Headname = Headname;
    this.Url = Url;

  }


}
