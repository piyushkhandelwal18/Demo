import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StatisticCard1Component } from './statistic-card1.component';

describe('StatisticCard1Component', () => {
  let component: StatisticCard1Component;
  let fixture: ComponentFixture<StatisticCard1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StatisticCard1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StatisticCard1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
