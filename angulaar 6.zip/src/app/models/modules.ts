export class AppModule{
    Name: string;
    Modules : Module[];
}

export class Module{
    Name: string
    Url: string
}