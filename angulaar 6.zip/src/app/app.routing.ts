import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core/src/metadata/ng_module';
import { ProductDashboardComponent } from './components/product/product-dashboard/product-dashboard.component';
import { ReportDashboardComponent } from './components/report/report-dashboard/report-dashboard.component';
import { InventoryDashboardComponent } from './components/inventory/inventory-dashboard/inventory-dashboard.component';
import { AccountDashboardComponent } from './components/account/account-dashboard/account-dashboard.component';
import { CompanyDashboardComponent } from './components/company/company-dashboard/company-dashboard.component';
import { MainDashboardComponent } from './components/main/main-dashboard/main-dashboard.component';
import { CategoryListComponent } from './components/Product/category/category-list/category-list.component';
import { CategoryDetailComponent } from './components/Product/Category/category-detail/category-detail.component';
import { CategoryEditComponent } from './components/Product/Category/category-edit/category-edit.component';
import { ProductListComponent } from './components/Product/product/product-list/product-list.component';
import { ProductDetailComponent } from './components/Product/Product/product-detail/product-detail.component';
import { ProductEditComponent } from './components/Product/Product/product-edit/product-edit.component';
import { UnitListComponent } from './components/Product/Unit/unit-list/unit-list.component';
import { UnitDetailComponent } from './components/Product/Unit/unit-detail/unit-detail.component';
import { UnitEditComponent } from './components/Product/unit/unit-edit/unit-edit.component';
import { ComboListComponent } from './components/Product/combo/combo-list/combo-list.component';
import { ComboDetailComponent } from './components/Product/Combo/combo-detail/combo-detail.component';
import { ComboEditComponent } from './components/Product/Combo/combo-edit/combo-edit.component';
import { RecipeListComponent } from './components/Product/Recipe/recipe-list/recipe-list.component';
import { RecipeDetailComponent } from './components/Product/Recipe/recipe-detail/recipe-detail.component';
import { RecipeEditComponent } from './components/Product/recipe/recipe-edit/recipe-edit.component';
import { LoginComponent } from './components/login/login.component';

export const AppRoutes: Routes = [
    
    { path: '', component: LoginComponent },
    //Main modules

    { path: 'main', component: MainDashboardComponent },
    { path: '', component: MainDashboardComponent },
    { path: 'product', component: ProductDashboardComponent },
    { path: 'report', component: ReportDashboardComponent },
    { path: 'inventory', component: InventoryDashboardComponent },
    { path: 'account', component: AccountDashboardComponent },
    { path: 'company', component: CompanyDashboardComponent },

    //Product Module
    { path: 'categorylist', component: CategoryListComponent },
    { path: 'categorydetail', component: CategoryDetailComponent },
    { path: 'categoryedit', component: CategoryEditComponent },

    { path: 'productlist', component: ProductListComponent},
    { path: 'productdetail', component: ProductDetailComponent },
    { path: 'productedit', component: ProductEditComponent },

    { path: 'categorylist', component: CategoryListComponent },
    { path: 'categorydetail', component: CategoryDetailComponent },
    { path: 'categoryedit', component: CategoryEditComponent },

    { path: 'unitlist', component: UnitListComponent },
    { path: 'unitdetail', component: UnitDetailComponent },
    { path: 'unitedit', component: UnitEditComponent },

    { path: 'combolist', component: ComboListComponent },
    { path: 'combodetail', component: ComboDetailComponent },
    { path: 'comboedit', component: ComboEditComponent },

    { path: 'recipelist', component: RecipeListComponent },
    { path: 'recipedetail', component: RecipeDetailComponent },
    { path: 'recipeedit', component: RecipeEditComponent },

];

export const ROUTING: ModuleWithProviders = RouterModule.forRoot(AppRoutes);