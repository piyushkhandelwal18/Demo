import { Injectable } from '@angular/core';
import { LoginResponse } from '../models/login';
import { DbService } from './db.service';

@Injectable()
export class StorageService {

  loginResponse: LoginResponse;

  constructor(private _db: DbService) { }


  public saveLoginResponse(response: LoginResponse) {
    this._db.saveLoginResponse(response);
    localStorage.setItem('authkey', response.AuthKey);
  }

  public logout() {
    this._db.logout();
  }

  public async getLoginResponse() {
    this.loginResponse = new LoginResponse();
    await this._db.getLoginResponse().then((data: LoginResponse) => { this.loginResponse = data; });
    return this.loginResponse;
  }
}
